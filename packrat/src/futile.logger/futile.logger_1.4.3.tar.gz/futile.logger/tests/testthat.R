library(testthat)
library(futile.logger)
test_check("futile.logger")
